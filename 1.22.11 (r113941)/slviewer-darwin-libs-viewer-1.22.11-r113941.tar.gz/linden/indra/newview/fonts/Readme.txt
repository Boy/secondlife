Copyright Information Regarding Fonts, Disclaimer of Warranties

This license applies to the files named MtBkLfRg.ttf and MtBdLfRg.ttf
in this directory, referred to hereafter as "Meta font software files".

The Meta font software files contained in this folder are the
copyrighted property of FSI FontShop International ("FSI") and are
licensed by FSI solely for use by Linden Research, Inc. and by
residents or users of Second Life in the Second Life environment,
subject to the Second Life Terms of Service.  These Meta font software
files may not be copied by residents or developers of Second Life or
used by them for any other purpose whatsoever.

FSI and its suppliers make no warranties express or implied relating
to the Meta font software, including without limitation, warranties as
to non-infringement of third party rights, merchantability, or fitness
for any particular purpose. In no event will FSI or its suppliers be
liable to you for any damages, including without limitation,
consequential, incidental or special damages, including any lost
profits or lost savings, even if a FSI representative has been advised
of the possibility of such damages, or for any claim by any third
party.
