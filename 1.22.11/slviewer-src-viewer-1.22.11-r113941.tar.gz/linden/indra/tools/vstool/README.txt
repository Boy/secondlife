VSTool is a command line utility to manipulate VisualStudio settings. 

The windows cmake project configuration uses VSTool.exe

A handy upgrade:
 figure out how to make cmake build this csharp app
 - or write the app using script (jscript?!?) so it doesn't need to be built.


